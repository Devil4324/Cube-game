# Cube game

A Pen created on CodePen.io. Original URL: [https://codepen.io/Devil4324/pen/KKOEVrr](https://codepen.io/Devil4324/pen/KKOEVrr).

